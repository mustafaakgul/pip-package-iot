from setuptools import setup

setup(name='package-iot',
      version='0.0',
      description='Calculate and visuallize, Gaussian, Binomial and Normal distributions',
      packages=['package-iot'],
      author_email='sjahnaviprasad@gmail.com',
      zip_safe=False)
